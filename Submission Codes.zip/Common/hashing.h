#ifndef HASHING_H
#define HASHING_H

void hashing(const char *src, const char *dest);

#endif